<?php

use Illuminate\Database\Seeder;
use App\Models\SYSCOM;
use App\Models\SYSNOR;

class SYSCOMTableSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);

        $RunNo1 = new SYSNOR();
        $RunNo1->SNTABL = 'SYSCOM';
        $RunNo1->SNNOUR = '2';
        $RunNo1->SNRGID = 'Default';
        $RunNo1->SNRGDT = Date("Y-m-d H:i:s");
        $RunNo1->SNCHID = 'Default';
        $RunNo1->SNCHDT = Date("Y-m-d H:i:s");
        $RunNo1->SNCHNO = '0';
        $RunNo1->SNDPFG = '1';
        $RunNo1->SNDLFG = '0';
        $RunNo1->SNCSID = 'Default';
        $RunNo1->SNCSDT = Date("Y-m-d H:i:s");
        $RunNo1->SNSRCE = 'FirstSetup';
        $RunNo1->save();

        $Demo = new SYSCOM();
        $Demo->SCCOMSIY = '1';
        $Demo->SCCODE = 'DEMO';
        $Demo->SCNAME = 'DEMO NAME';
        $Demo->SCDESC = 'DEMO DESCRIPTION';
        $Demo->SCRGID = 'Default';
        $Demo->SCRGDT = Date("Y-m-d H:i:s");
        $Demo->SCCHID = 'Default';
        $Demo->SCCHDT = Date("Y-m-d H:i:s");
        $Demo->SCCHNO = '0';
        $Demo->SCDPFG = '1';
        $Demo->SCDLFG = '0';
        $Demo->SCCSID = 'Default';
        $Demo->SCCSDT = Date("Y-m-d H:i:s");
        $Demo->SCSRCE = 'FirstSetup';
        $Demo->save();


        $Demo = new SYSCOM();
        $Demo->SCCOMSIY = '2';
        $Demo->SCCODE = 'WILI';
        $Demo->SCNAME = 'WILI NAME';
        $Demo->SCDESC = 'WILI DESCRIPTION';
        $Demo->SCRGID = 'Default';
        $Demo->SCRGDT = Date("Y-m-d H:i:s");
        $Demo->SCCHID = 'Default';
        $Demo->SCCHDT = Date("Y-m-d H:i:s");
        $Demo->SCCHNO = '0';
        $Demo->SCDPFG = '1';
        $Demo->SCDLFG = '0';
        $Demo->SCCSID = 'Default';
        $Demo->SCCSDT = Date("Y-m-d H:i:s");
        $Demo->SCSRCE = 'FirstSetup';
        $Demo->save();

    }
}
