<?php

use Illuminate\Database\Seeder;
use App\Models\TBLUSR;
use App\Models\SYSNOR;

class TBLUSRTableSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        $RunNo1 = new SYSNOR();
        $RunNo1->SNTABL = 'TBLUSR';
        $RunNo1->SNNOUR = '2';
        $RunNo1->SNRGID = 'Default';
        $RunNo1->SNRGDT = Date("Y-m-d H:i:s");
        $RunNo1->SNCHID = 'Default';
        $RunNo1->SNCHDT = Date("Y-m-d H:i:s");
        $RunNo1->SNCHNO = '0';
        $RunNo1->SNDPFG = '1';
        $RunNo1->SNDLFG = '0';
        $RunNo1->SNCSID = 'Default';
        $RunNo1->SNCSDT = Date("Y-m-d H:i:s");
        $RunNo1->SNSRCE = 'FirstSetup';        
        $RunNo1->save();

        $Admin = new TBLUSR();
        $Admin->TUCOMSIY = '1';
        $Admin->TUUSERIY = '1';
        $Admin->TUUSER = 'ADMIN';
        $Admin->TUNAME = 'ADMINISTRATOR';
        $Admin->TUPSWD = 'ADMIN';
        $Admin->TURGID = 'Default';
        $Admin->TURGDT = Date("Y-m-d H:i:s");
        $Admin->TUCHID = 'Default';
        $Admin->TUCHDT = Date("Y-m-d H:i:s");
        $Admin->TUCHNO = '0';
        $Admin->TUDPFG = '1';
        $Admin->TUDLFG = '0';
        $Admin->TUCSID = 'Default';
        $Admin->TUCSDT = Date("Y-m-d H:i:s");
        $Admin->TUSRCE = 'FirstSetup';
        $Admin->save();

        $DemoUser = new TBLUSR();
        $DemoUser->TUCOMSIY = '1';
        $DemoUser->TUUSERIY = '2';
        $DemoUser->TUUSER = 'DEMO';
        $DemoUser->TUNAME = 'USER DEMO';
        $DemoUser->TUPSWD = 'DEMO';
        $DemoUser->TURGID = 'Default';
        $DemoUser->TURGDT = Date("Y-m-d H:i:s");
        $DemoUser->TUCHID = 'Default';
        $DemoUser->TUCHDT = Date("Y-m-d H:i:s");
        $DemoUser->TUCHNO = '0';
        $DemoUser->TUDPFG = '1';
        $DemoUser->TUDLFG = '0';
        $DemoUser->TUCSID = 'Default';
        $DemoUser->TUCSDT = Date("Y-m-d H:i:s");
        $DemoUser->TUSRCE = 'FirstSetup';
        $DemoUser->save();

        
    }
}
