<?php

use Illuminate\Database\Seeder;
use App\Models\TBLDSC;
use App\Models\TBLSYS;

class TBLDSCTBLSYSTableSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);

        $TBLDSC = new TBLDSC();
        $TBLDSC->TDCOMSIY = '1';
        $TBLDSC->TDDSCD = 'YN';
        $TBLDSC->TDDSNM = 'YESNO';
        $TBLDSC->TDLGTH = '1';
        $TBLDSC->TDRGID = 'Default';
        $TBLDSC->TDRGDT = Date("Y-m-d H:i:s");
        $TBLDSC->TDCHID = 'Default';
        $TBLDSC->TDCHDT = Date("Y-m-d H:i:s");
        $TBLDSC->TDCHNO = '0';
        $TBLDSC->TDDPFG = '1';
        $TBLDSC->TDDLFG = '0';
        $TBLDSC->TDCSID = 'Default';
        $TBLDSC->TDCSDT = Date("Y-m-d H:i:s");
        $TBLDSC->TDSRCE = 'FirstSetup';
        $TBLDSC->save();


        // $TBLSYS->TSSYV1 = ''; $TBLSYS->TSSYV2 = ''; $TBLSYS->TSSYV3 = '';
        // $TBLSYS->TSSYT1 = ''; $TBLSYS->TSSYT2 = ''; $TBLSYS->TSSYT3 = '';
        // $TBLSYS->TSLSV1 = ''; $TBLSYS->TSLSV2 = ''; $TBLSYS->TSLSV3 = '';
        // $TBLSYS->TSLST1 = ''; $TBLSYS->TSLST2 = ''; $TBLSYS->TSLST3 = '';


        $TBLSYS = new TBLSYS();
        $TBLSYS->TSCOMSIY = '1';
        $TBLSYS->TSDSCD = 'YN';
        $TBLSYS->TSSYCD = 'Y';
        $TBLSYS->TSSYNM = 'YES';
        $TBLSYS->TSRGID = 'Default';
        $TBLSYS->TSRGDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSCHID = 'Default';
        $TBLSYS->TSCHDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSCHNO = '0';
        $TBLSYS->TSDPFG = '1';
        $TBLSYS->TSDLFG = '0';
        $TBLSYS->TSCSID = 'Default';
        $TBLSYS->TSCSDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSSRCE = 'FirstSetup';
        $TBLSYS->save();


        $TBLSYS = new TBLSYS();
        $TBLSYS->TSCOMSIY = '1';
        $TBLSYS->TSDSCD = 'YN';
        $TBLSYS->TSSYCD = 'N';
        $TBLSYS->TSSYNM = 'NO';
        $TBLSYS->TSRGID = 'Default';
        $TBLSYS->TSRGDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSCHID = 'Default';
        $TBLSYS->TSCHDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSCHNO = '0';
        $TBLSYS->TSDPFG = '1';
        $TBLSYS->TSDLFG = '0';
        $TBLSYS->TSCSID = 'Default';
        $TBLSYS->TSCSDT = Date("Y-m-d H:i:s");
        $TBLSYS->TSSRCE = 'FirstSetup';
        $TBLSYS->save();
        
    }
}
